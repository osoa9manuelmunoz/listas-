package Listas_dobles;

public class Main {
	
	 public static void main(String[] args) {
	        Lista lista = new Lista();
	        lista.add(2);
	        lista.add(3);
	        lista.add(4);
	        lista.add(6);
	        lista.add(5);
	        lista.add(4);
	        lista.add(null);
	        lista.add(8);
	        lista.add(null);
	        lista.add(lista.head.getnext(), 9);
	        Nodo n = lista.head;
	        for (int i = lista.c; i>=1; i--) {
	            System.out.println(n.getvalor());
	            n=n.getnext();
	        }
	        
	        
	        System.out.println ("Si se debe incluir el elemento 100: " + lista.contains(100));
	        System.out.println("------------------------");
	        
	        System.out.println ("El noveno elemento es: " + lista.get(null));
	        System.out.println("------------------------");
	        
	        System.out.println("nodos: "+lista.nodeOf(129));
	        System.out.println("------------------------");
	        
	        
	        System.out.println("se encontro el 5? : "+lista.contains(5));
	        System.out.println("------------------------");
	        
	    }

}
