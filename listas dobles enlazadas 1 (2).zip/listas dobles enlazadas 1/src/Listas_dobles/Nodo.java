package Listas_dobles;

import interfa.LinkedListNode;

public class Nodo implements LinkedListNode {
    
    private Object valor;
    private Nodo next=null;
    private Nodo prev=null;
    
    public Nodo(Object valor){
        this.valor=valor;
    }
    public Object getvalor(){
        return valor;
    }
    public void setvalor(Object valor){
        this.valor=valor;
    }
    public Nodo getnext(){
        return next;
    }
    public void setnext(Nodo nodo){
        this.next=nodo;
    }
    public Nodo getprev(){
        return prev;
    }
    public void setprev(Nodo nodo){
        this.prev=nodo;
    }

    
}
